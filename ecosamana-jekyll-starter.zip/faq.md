---
title: FAQ & Safety
---

- **Is alcohol served?** No — family excursion.
- **Can kids join?** Yes! Lifejackets required.
- **Head diving?** Not in restricted reef/shallow areas.
- **What to bring?** Swimwear, towel, sunscreen, camera.
- **Weather policy?** We may reschedule or refund depending on conditions.
