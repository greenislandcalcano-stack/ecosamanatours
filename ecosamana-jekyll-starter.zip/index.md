---
title: EcoSamaná Adventures
layout: page
image: /assets/images/hero/samana-secret-treasure-hero.jpg
subtitle: Family-friendly eco tours & pirate treasure hunts in Santa Bárbara de Samaná.
---

<div class="grid">
  <div class="card">
    <h3>The Secret Treasure</h3>
    <p>Boat & snorkeling treasure hunt across 4 beaches. Cruise: 3h • Hotel: 4h30. Snacks/Buffet included.</p>
    <a class="btn" href="/excursions/secret-treasure/">Explore & Book</a>
  </div>
  <div class="card">
    <h3>Whale Watching</h3>
    <p>Seasonal humpback encounters in Samaná Bay with certified guides and safety first.</p>
    <a class="btn" href="/excursions/whale-watching/">See Details</a>
  </div>
  <div class="card">
    <h3>Waterfalls & Nature</h3>
    <p>Jungle paths, river dips, local culture. Ideal for families and photographers.</p>
    <a class="btn" href="/excursions/waterfalls/">Plan Your Visit</a>
  </div>
</div>

<p class="badge">No alcohol served on board • Lifejackets required for kids • Respect reef zones</p>
