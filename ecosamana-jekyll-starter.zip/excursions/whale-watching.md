---
title: Whale Watching – Samaná Bay
image: /assets/images/hero/whales.jpg
---

Peak season, certified guides, safety-first vessels. Bring a hat, sunscreen, and a light jacket.
